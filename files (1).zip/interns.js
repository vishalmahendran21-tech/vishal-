// Add one line per certificate. Certificate ID pattern: VMTXIN + YY + MM + start-day + serial.
var INTERNS = [
  {id:"VMTXIN26061103", name:"Rohith A", dom:"Artificial Intelligence & Machine Learning", college:"St. Peter's College of Engineering and Technology", yr:"III Year, Computer Science and Engineering", from:"11/06/2026", to:"25/06/2026", issued:"26/06/2026"},
  {id:"VMTXIN26081817", name:"P Florence Hepsiba", dom:"Data Analyst Intern", college:"St Peter's College of Engineering and Technology, Avadi", yr:"", from:"18/08/2026", to:"29/08/2026", issued:"29/08/2026"}
];
